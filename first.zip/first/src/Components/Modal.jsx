function Modal() {
  return (
    <div className="modal">
      <p>Are you Sure?</p>
      <button className="btn btn--alt"> Cancel</button>
      <button className="btn"> Confirm, Delete</button>
    </div>
  );
}

export default Modal;
