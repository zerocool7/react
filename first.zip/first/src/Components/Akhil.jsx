function Akhil(props) {
  function deleteHandler() {}
  return (
    <div className="card">
      <h2>
        {props.name} <i>likes to Learn</i> {props.color}
      </h2>
      <div className="actions">
        <button className="btn" onClick={deleteHandler}>
          DELETE
        </button>
      </div>
    </div>
  );
}

export default Akhil;
