import "./App.css";
import Akhil from "./Components/Akhil";
import Modal from "./Components/Modal";

function App() {
  return (
    <div>
      <h1> My ToDos</h1>
      <Akhil name="Akhil" color="Full Stack" />
      <Modal />
    </div>
  );
}

export default App;
